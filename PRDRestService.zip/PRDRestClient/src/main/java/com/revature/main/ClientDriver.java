package com.revature.main;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.revature.domain.Products;

public class ClientDriver {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://localhost:8080/PRDRestService/rest/products");

		// Get request for a list of all the stored products
		Builder getProductsBuilder2 = webTarget.request();
		Response getProductsResponse2 = getProductsBuilder2.accept(MediaType.APPLICATION_JSON).get();

		List<Products> productslist = new ArrayList<>();
		productslist = getProductsResponse2.readEntity(ArrayList.class);
		System.out.println(productslist);
	}
}