package com.revature.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.domain.Products;
import com.revature.util.ConnFactory;

public class ProductsDAOImpl {

	/*
	 * ID - int, primary key Name - String Code Name - String, unique Department -
	 * String PRDType - String (Full/Expedited) ProductType - String
	 * (Physical/Process) Description - String isPrototype - boolean
	 */

	public static List<Products> prdList = new ArrayList<>();
	public static ConnFactory cf = ConnFactory.getInstance();

	static {
		System.out.println("Hello!");
		Connection conn = cf.getConnection();
		try {
			Statement stmt = conn.createStatement();
			String queryString = "select * from product";
			ResultSet rst = stmt.executeQuery(queryString);
			while (rst.next()) {
				prdList.add(new Products(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4),
						rst.getString(5), rst.getString(6), ((rst.getInt(7) == 1) ? true : false)));
				System.out.println("Testing!!" + prdList);
			}
		} catch (Exception ex) {
			System.out.println("Error caught at ProductsDAOImpl to select *: " + ex.getMessage());
		}
	}

	public static List<Products> getAllProducts() {
		return prdList;
	}

	public static Products getInfoByType(String type) {
		for (Products p : prdList) {
			if (p.getPrdType() == type) {
				return p;
			}
		}
		return null;
	}

	public static void addProduct(Products p) {
		prdList.add(p);
	}

	// removing by codename
	public static void removeProduct(String name) {
		for (int i = 0; i < prdList.size(); i++) {
			if (prdList.get(i).getPrdCdName() == name) {
				prdList.remove(name);
			}
		}
	}

}
